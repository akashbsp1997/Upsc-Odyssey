import { describe, expect, it } from 'vitest';
import { campaignSchema, type Campaign } from './schema';
import dayOne from './day-01.json';

const generated = Object.values(import.meta.glob<Campaign>('./campaigns/day-*.json', { eager: true, import: 'default' }));
const library = [campaignSchema.parse(dayOne), ...generated.map((campaign) => campaignSchema.parse(campaign))].sort((a, b) => a.day - b.day);

describe('180-day bundled campaign', () => {
  it('contains every day and the requested date range', () => {
    expect(library).toHaveLength(180);
    expect(library.map((campaign) => campaign.day)).toEqual(Array.from({ length: 180 }, (_, index) => index + 1));
    expect(library[0].planDate).toBe('2026-10-19');
    expect(library[179].planDate).toBe('2027-04-16');
  });

  it('includes learning, practice, source leads and transparent PYQ status each day', () => {
    for (const campaign of library) {
      expect(campaign.lessons.length).toBeGreaterThan(0);
      expect(campaign.activities.length).toBeGreaterThan(0);
      expect(campaign.sourceReferences?.length).toBeGreaterThan(0);
      expect(campaign.pyqReferences?.[0].url).toContain('upsc.gov.in');
      expect(campaign.pyqReferences?.[0].mappingStatus).toMatch(/topic-level/);
    }
  });

  it('adds a written boss challenge every seventh day', () => {
    for (const campaign of library.filter((entry) => entry.day % 7 === 0)) {
      expect(campaign.activities.some((activity) => activity.type === 'mains' && activity.points >= 25)).toBe(true);
    }
  });
});
